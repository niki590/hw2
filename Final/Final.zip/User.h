#ifndef User_h
#define User_h
#include "List.h"
#include <stdbool.h>
#define MAX_LEN 256

typedef struct User_t* PUSER;
void termination();
PUSER User_Create(char* name);
void User_Delete(PUSER name);
Result User_addFriend(PUSER name1, char* name2,bool a);
Result User_removeFriend(PUSER name1, char* name2);
char* User_getName(PUSER user_name);
NODE* User_getFriendsList(PUSER user_name);
int User_getFriendsNum(PUSER user_name);
void User_print(PUSER user_name);

#endif//User_h

