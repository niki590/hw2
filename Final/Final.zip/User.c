#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "List.h"
#include "User.h"

typedef struct User_t {
	char* name;
	NODE* friends_list;
	int friend_count;
}USER;


//******************************************************************************
//* function name :User_Create
//* Description :recieves a name and creates a new user
//* Parameters:new user name
//* Return Value: pointer to new user struct
//******************************************************************************
PUSER User_Create(char* newname) 
{
	if (newname==NULL) //checks if input name is legit
		return NULL;
	PUSER s = (PUSER)malloc(sizeof(USER));
	if (s == NULL) 
		return NULL;
	s->friends_list = link_create();
		if (s->friends_list == NULL)
			return NULL;
		s->name = malloc(strlen(newname) + 1);
		if (s->name == NULL)
			return NULL;
		strcpy(s->name, newname);
		s->friend_count = 0;
	return s;      //user has been created successfully - return pointer to the new user
}
//******************************************************************************
//* function name :User_Delete
//* Description :Deletes existing user
//* Parameters:pointer to User 
//* Return Value: 
//******************************************************************************
void User_Delete(PUSER user)
{
	link_delete(user->friends_list);
	free(user->name);
	free(user);
}
//******************************************************************************
//* function name :User_addFriend
//* Description :add a friend to another users friend list if that friend isnt already there.
//*and increase the user's friend count
//* Parameters:pointer to User and name of friend to be added
//* Return Value: FAILURE/SUCCESS
//******************************************************************************
Result User_addFriend(PUSER name1, char* name2,bool a)
{
	bool already_connected = link_find(name1->friends_list, name2);
	if (already_connected) 
		return FAILURE;
	else
	{
		char *save = malloc(strlen(name2) + 1);
		if (save == NULL)
			a = true;
		strcpy(save, name2);
		Result malloc_check =link_push(name1->friends_list, save);
		if (!malloc_check)
		{
			a = true;			// indicates that malloc failed
			return FAILURE;
		}
		name1->friend_count++;	//increase the given user's friend count
	}
	return SUCCESS;
}

//******************************************************************************
//* function name :User_removeFriend
//* Description :remove a friend from another users friend list if that friend is there.
//*and decrease the user's friend count
//* Parameters:pointer to User and name of friend to be removed
//* Return Value: FAILURE/SUCCESS
//******************************************************************************
Result User_removeFriend(PUSER name1, char* name2) {
	bool does_exist = link_find(name1->friends_list, name2);
		if (!does_exist)
			return FAILURE;
		else
		{
			Result a=link_find_delete(name1->friends_list, name2);
			name1->friend_count--;	//decrease the given user's friend count
		}
		return SUCCESS;
}
//******************************************************************************
//* function name :User_getName
//* Description :return user's name using a given PUSER
//* Parameters:pointer to User
//* Return Value: User's "name" field
//******************************************************************************
char* User_getName(PUSER user_name){
	if (user_name == NULL)
	{
		printf("given pointer to getname is null");
		return NULL;
	}
	return user_name->name;
}
//******************************************************************************
//* function name :User_getFriendsList
//* Description :return pointer to the beginning of given user's friends list
//* Parameters:pointer to User
//* Return Value: pointer to User's friends list
//******************************************************************************
NODE* User_getFriendsList(PUSER user_name) {
	if (user_name == NULL) {
		printf(" Null ptr during attempt to get friends list");
		return NULL;
	}
	return user_name->friends_list;
}
//******************************************************************************
//* function name :User_getFriendsNum
//* Description :return number of friends of a certain user
//* Parameters:pointer to User
//* Return Value: friend count
//******************************************************************************
int User_getFriendsNum(PUSER user_name) 
{
	if (user_name == NULL) {
		printf("termination cause: Null ptr during attempt to get a friend count");
		return 0;
	}
	return user_name->friend_count;
}

//******************************************************************************
//* function name :User_print
//* Description :prints a user's friends list
//* Parameters:pointer to User
//* Return Value:
//******************************************************************************
void User_print(PUSER user_name) {
	if (user_name->friend_count == 1) {
		printf("User's name: %s\nThe user has 1 friend:\n", user_name->name);
		link_print(user_name->friends_list);
	}
	else
	{
		printf("User's name: %s\nThe user has %d friends:\n", user_name->name, user_name->friend_count);
		link_print(user_name->friends_list);
	}
		return;
}
